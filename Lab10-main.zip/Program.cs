﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Lab1CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 5, 6, 7, 5, 1, 3, 9 };
            int[] narr = arr;
            
            Array.Copy(arr, narr, arr.Length);

            int[] z = arr.Concat(narr).ToArray();
            Array.Sort(z);
            for (int i = 0; i < z.Length; i++)
            {
                Console.WriteLine(z[i]);
            }
        }
    }
}