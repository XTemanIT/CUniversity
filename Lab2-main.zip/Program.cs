﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Lab1CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            double u = 0, S = 1;
            int start, end;
            Console.WriteLine("Введите начальное значение: ");
            do
            {
                start = Convert.ToInt32(Console.ReadLine());
                if (start < 0)
                {
                    Console.WriteLine("Введите другое значение: ");
                }
            } while (start < 0);
            Console.WriteLine("Введите макс значение: ");
            do
            {
                end = Convert.ToInt32(Console.ReadLine());
                if (end < start)
                {
                    Console.WriteLine("Введите другое значение: ");
                }
            } while (end < start);
            for (int i = start; i <= end; i++)
            {
                u = ((Math.Pow(i, 2) + Math.Pow(-1, i - 1) + 2 * i - 1) / (Math.Pow(i, 2) + 8));
                S += u;
                Console.WriteLine("u" + i + "=" + u);
                u = 0;
            }
            Console.WriteLine("Сумма ряда = " + S);
            Console.ReadLine();
        }

    }
}
