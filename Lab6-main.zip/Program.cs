﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Lab1CSharp
{
    public class DoubleNumber
    {
        public void Sort()
        {
            double num = 3457.21346;
            var temp = num.ToString().Split(',');
            foreach (var item in temp)
            {
                var array = item.ToArray();
                for (int i = array.Length - 1; i >= 0; i--)
                {
                    Console.Write(array[i]);
                }
                Console.Write(".");
            }
        }
        public void Sort(double num)
        {
            var temp = num.ToString().Split(',');
            foreach (var item in temp)
            {
                var array = item.ToArray();
                for (int i = array.Length - 1; i >= 0; i--)
                {
                    Console.Write(array[i]);
                }
                Console.Write(".");
            }
        }
    }
    public class Line
    {
        public void RecursionString(string[] sts)
        {
            foreach (var item in sts)
            {
                if (sts != null)
                {
                    Console.WriteLine(item.Reverse().ToArray());
                }
                else Console.WriteLine("Error");
            }
        }
        public void RecursionString()
        {
            string word = "I love Apple";
            for (int i = word.Length - 1; i >= 0; i--)
            {
                Console.Write(word[i]);
            }
        }
    }
    public class Number
    {
        public void RecursionNumber(int[] nums)
        {
            Array.Reverse(nums);
            foreach (var item in nums)
            {
                Console.WriteLine(item);
            }
        }
        public void RecursionNumber(int numebr)
        {
            Console.WriteLine(numebr.ToString().Reverse().ToArray());
        }
    }
    public class MagicSing
    {
        public void MagicRecursion(string[] text)
        {
            foreach (var item in text)
            {
                if (text != null)
                {
                    Console.Write(item.Reverse().ToArray());
                }
                else Console.WriteLine("Error");
            }
        }
        public void Mag(string[] text)
        {
            foreach (var item in text)
            {
                if (text != null)
                {
                    item.Reverse().ToArray();
                }
                else Console.WriteLine("Error");
            }
            string newword = null;
            string textold = Regex.Replace(text[1], " {2,}", "    ");
            foreach (var el in textold)
            {
                if (Char.IsWhiteSpace(el))
                {
                    newword += ','.ToString();
                    continue;
                }
                newword += el.ToString();
            }
            Console.WriteLine($"New string: {newword}");
        }
    }
    public class DontReverse
    {
        public void DoReveres()
        {
            int[] num = { 8, 7, 4, 6, 8 };
            for (int i = 0; i < num.Length / 2; i++)
            {
                int temp = num[i];
                num[i] = num[num.Length - i - 1];
                num[num.Length - i - 1] = temp;
            }
            Console.Write(string.Join(",", num));
        }
        public void DoReveres2(int[] num)
        {
            for (int i = 0; i < num.Length / 2; i++)
            {
                int temp = num[i];
                num[i] = num[num.Length - i - 1];
                num[num.Length - i - 1] = temp;
            }
        }
        public void DoReveres3(out int[] num)
        {
            num = new int[] { 1, 2, 3, 4 };
            for (int i = num.Length - 1; i >= 0; i--)
            {
                Console.WriteLine(num[i]);
            }
        }
        public void DoReveres4(ref int[] num)
        {
            for (int i = num.Length - 1; i >= 0; i--)
            {
                Console.Write(num[i]);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Number number = new Number();
            number.RecursionNumber(new int[] { 2, 4, 5, 8, 7, 6 });
            number.RecursionNumber(123);
            Line line = new Line();
            line.RecursionString(new string[] { "Apple" });
            line.RecursionString();
            DoubleNumber doubleNumber = new DoubleNumber();
            doubleNumber.Sort();
            MagicSing magicSing = new MagicSing();
            magicSing.MagicRecursion(new string[2] { "Artem", "Swift" });
            DontReverse dontReverse = new DontReverse();
            dontReverse.DoReveres();
            int[] num;
            dontReverse.DoReveres3(out num);
            num = new int[] { 1, 2, 3, 4 };
            dontReverse.DoReveres4(ref num);
        }

    }
}