﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Lab1CSharp
{
    class BPhone
    {
        protected string telNumber = "878-88-88";
        protected List<string> availableNumbers = new List<string> {
            "0","1","2","3","4","5","6","7","8","9"
        };
        protected void makeCall()
        {
            Console.WriteLine("Звонок");
        }
        protected void takeCall()
        {
            Console.WriteLine("Принять звонок");
        }
    }
    class ButtonPhone : BPhone
    {
        protected ButtonPhone()
        {
            availableNumbers.AddRange(new List<string>
            {
                "*","#"
            });
        }
        protected void printTelNumber()
        {
            Console.WriteLine("878-88-88");
        }
    }
    class Phone : ButtonPhone
    {
        protected Phone()
        {
            availableNumbers.AddRange(new List<string>
            {
                "@","$","%","&","(",")"
            });
        }
        protected string resulution { get; set; }
        protected string screenSize { get; set; }
        private void sendSmS()
        {
            Console.WriteLine("Смс отправлено");
        }
        private void takeSmS()
        {
            Console.WriteLine("Смс получено");
        }
    }
    class BNPhone : Phone
    {
        protected bool twoSim = true;
        protected string secondNumber { get; set; }
        protected void sendMMS_firstSim()
        {
            Console.WriteLine("ММС отправлено");
        }
        protected void takeMMS_firstSim()
        {
            Console.WriteLine("ММС получено");
        }
        protected void sendMMS_secondSim()
        {
            Console.WriteLine("ММС отправлено");
        }
        protected void takeMMS_secondSim()
        {
            Console.WriteLine("ММС получено");
        }
        protected void takeCall_firstSim()
        {
            Console.WriteLine("ММС отправлено");
        }
        protected void makeCall_firstSim()
        {
            Console.WriteLine("ММС получено");
        }
        protected void takeCall_secondSim()
        {
            Console.WriteLine("ММС отправлено");
        }
        protected void makeCall_secondSim()
        {
            Console.WriteLine("ММС получено");
        }
    }
    class SmartPhone
    {
        protected bool SensorDisplay = true;
        protected int maxCountOfTouches { get; set; }
        protected int countOfCameras { get; set; }
        protected void makePhoto_firstCam()
        {
            Console.WriteLine("Фото");
        }
        protected void makePhoto_second()
        {
            Console.WriteLine("Фото");
        }
        protected void recordVideo_firstCam()
        {
            Console.WriteLine("Запись");
        }
        protected void recordVideo_second()
        {
            Console.WriteLine("Запись");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
